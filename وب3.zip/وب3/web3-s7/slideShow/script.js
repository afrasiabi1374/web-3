// JavaScript Document
window.onload = initiateLinks;

function initiateLinks() {
	
	document.getElementById('prevLink').onclick = processPrevious;
	document.getElementById('nextLink').onclick = processNext;
	
}


var myPix = ['students0.jpg','students1.jpg','students2.jpg'];

var thisPic = 0;

setInterval(function(){processNext()},4000)

function processPrevious() {
	if (thisPic == 0) {
		
		thisPic = myPix.length;
	}
	
	thisPic--;
	document.getElementById('myPicture').src = myPix[thisPic];
}

function processNext() {
	thisPic++;
	if ( thisPic == myPix.length  ) {
		
		thisPic = 0;
	}
	document.getElementById('myPicture').src = myPix[thisPic];
}

