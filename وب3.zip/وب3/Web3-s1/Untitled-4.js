// JavaScript Document

document.getElementById('demo').innerHTML = 'New Text';
document.getElementById('demo').style.color = 'red';